//Data Validation for non-empty password
//TODO
console.log("Login Script Loaded!")