var executeSQL = require('../dbPool');

//Main Driver functions for the forum categories

// retrieve signup page
exports.post_get = function (req,res,next){
  res.send("post_GET Not Yet implemented.");
};

//Display
exports.post_post = function (req,res,next){
  res.send("post_POST Not Yet implemented.");
};