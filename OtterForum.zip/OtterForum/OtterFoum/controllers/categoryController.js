var executeSQL = require('../dbPool');

// displays a list of
exports.category_list = function (req,res,next){
  res.send("Category_list Not Yet implemented.");
};

//Display relevant list of posts from a specific category (ie, Sports, Gardening etc..)
exports.category_get = function (req,res,next){
  res.send("Category_get Not Yet implemented.");
};
